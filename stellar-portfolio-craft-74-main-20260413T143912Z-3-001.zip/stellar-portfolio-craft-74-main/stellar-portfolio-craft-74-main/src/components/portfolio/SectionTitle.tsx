import { useScrollAnimation } from "@/hooks/useScrollAnimation";

interface Props { label: string; title: string; subtitle?: string; }

export default function SectionTitle({ label, title, subtitle }: Props) {
  const { ref, isVisible } = useScrollAnimation();
  return (
    <div ref={ref} className={`text-center mb-16 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
      <p className="font-mono text-sm text-primary tracking-widest uppercase mb-3">{label}</p>
      <h2 className="text-3xl md:text-4xl font-bold mb-4">{title}</h2>
      {subtitle && <p className="text-muted-foreground max-w-xl mx-auto">{subtitle}</p>}
    </div>
  );
}
