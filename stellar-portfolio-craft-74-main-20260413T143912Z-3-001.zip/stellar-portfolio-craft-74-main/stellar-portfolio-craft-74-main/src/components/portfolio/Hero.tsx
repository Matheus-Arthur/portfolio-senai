import { ArrowDown, Briefcase, Mail } from "lucide-react";
import logo from "@/assets/logo.png";

export default function Hero() {
  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
      {/* Background grid */}
      <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: "radial-gradient(circle, hsl(var(--primary)) 1px, transparent 1px)", backgroundSize: "40px 40px" }} />

      <div className="relative max-w-5xl mx-auto px-4 sm:px-6 text-center">
        <div className="animate-in mb-8">
          <img src={logo} alt="CyberPulse Innovations" className="h-28 w-28 md:h-36 md:w-36 mx-auto animate-float" />
        </div>

        <div className="animate-in animate-in-delay-1">
          <p className="font-mono text-sm text-primary tracking-widest uppercase mb-4">CyberPulse Innovations</p>
        </div>

        <h1 className="animate-in animate-in-delay-2 text-4xl sm:text-5xl md:text-7xl font-bold leading-tight mb-6">
          Segurança Digital<br />
          <span className="text-gradient">de Alto Nível</span>
        </h1>

        <p className="animate-in animate-in-delay-3 text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto mb-10">
          Protegemos sua empresa com soluções inovadoras em cibersegurança, desenvolvimento seguro e consultoria tecnológica desde 2026.
        </p>

        <div className="animate-in animate-in-delay-4 flex flex-col sm:flex-row gap-4 justify-center">
          <a href="#projects" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all glow">
            <Briefcase size={18} /> Ver Projetos
          </a>
          <a href="#contact" className="inline-flex items-center justify-center gap-2 px-8 py-3.5 rounded-xl border border-border text-foreground font-semibold hover:bg-muted transition-all">
            <Mail size={18} /> Contato
          </a>
        </div>

        <a href="#about" className="absolute bottom-10 left-1/2 -translate-x-1/2 text-muted-foreground hover:text-primary transition-colors animate-bounce">
          <ArrowDown size={24} className="bg-[#1d262a]/0 text-[#1d262a]/0 border-black/0" />
        </a>
      </div>
    </section>
  );
}
