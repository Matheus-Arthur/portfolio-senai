import SectionTitle from "./SectionTitle";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const categories = [
  {
    title: "Segurança",
    skills: [
      { name: "Pentest", level: 95 },
      { name: "SIEM/SOC", level: 90 },
      { name: "Análise de Malware", level: 85 },
      { name: "Forense Digital", level: 88 },
    ],
  },
  {
    title: "Desenvolvimento",
    skills: [
      { name: "Python", level: 92 },
      { name: "TypeScript", level: 88 },
      { name: "React", level: 85 },
      { name: "Node.js", level: 87 },
    ],
  },
  {
    title: "Infraestrutura",
    skills: [
      { name: "AWS / Azure", level: 90 },
      { name: "Docker / K8s", level: 88 },
      { name: "Linux", level: 95 },
      { name: "CI/CD", level: 85 },
    ],
  },
];

function SkillBar({ name, level, visible }: { name: string; level: number; visible: boolean }) {
  return (
    <div className="space-y-2">
      <div className="flex justify-between text-sm">
        <span className="font-medium">{name}</span>
        <span className="text-muted-foreground font-mono">{level}%</span>
      </div>
      <div className="h-2 rounded-full bg-muted overflow-hidden">
        <div className="h-full rounded-full bg-primary transition-all duration-1000 ease-out" style={{ width: visible ? `${level}%` : "0%" }} />
      </div>
    </div>
  );
}

export default function Skills() {
  const { ref, isVisible } = useScrollAnimation(0.1);
  return (
    <section id="skills" className="py-24 px-4 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        <SectionTitle label="Competências" title="Nossas Habilidades" subtitle="Domínio técnico em segurança, desenvolvimento e infraestrutura." />
        <div ref={ref} className="grid md:grid-cols-3 gap-8">
          {categories.map((cat, i) => (
            <div key={cat.title} className={`glass rounded-2xl p-6 space-y-5 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`} style={{ transitionDelay: `${i * 150}ms` }}>
              <h3 className="text-lg font-semibold text-primary">{cat.title}</h3>
              {cat.skills.map((s) => (
                <SkillBar key={s.name} {...s} visible={isVisible} />
              ))}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
