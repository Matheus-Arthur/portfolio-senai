import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { useCounter } from "@/hooks/useCounter";

const stats = [
  { value: 150, suffix: "+", label: "Projetos Entregues" },
  { value: 80, suffix: "+", label: "Clientes Satisfeitos" },
  { value: 99, suffix: "%", label: "Uptime Garantido" },
  { value: 5, suffix: "M+", label: "Ameaças Bloqueadas" },
];

function StatItem({ value, suffix, label, visible }: { value: number; suffix: string; label: string; visible: boolean }) {
  const count = useCounter(value, visible);
  return (
    <div className="text-center">
      <div className="text-4xl md:text-5xl font-bold text-primary font-mono">
        {count}{suffix}
      </div>
      <p className="text-sm text-muted-foreground mt-2">{label}</p>
    </div>
  );
}

export default function Stats() {
  const { ref, isVisible } = useScrollAnimation(0.2);
  return (
    <section className="py-20 px-4 bg-muted/30">
      <div ref={ref} className={`max-w-5xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-8 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
        {stats.map((s) => (
          <StatItem key={s.label} {...s} visible={isVisible} />
        ))}
      </div>
    </section>
  );
}
