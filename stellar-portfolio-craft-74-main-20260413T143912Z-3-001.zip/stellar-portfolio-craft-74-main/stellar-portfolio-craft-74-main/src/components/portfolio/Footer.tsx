import { Github, Linkedin, Twitter, ArrowUp } from "lucide-react";
import logo from "@/assets/logo.png";

export default function Footer() {
  return (
    <footer className="border-t border-border py-12 px-4">
      <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <img src={logo} alt="CyberPulse" className="h-8 w-8" />
          <span className="text-sm text-muted-foreground">© 2026 CyberPulse Innovations. Todos os direitos reservados.</span>
        </div>
        <div className="flex items-center gap-4">
          {[Github, Linkedin, Twitter].map((Icon, i) => (
            <a key={i} href="#" className="p-2 rounded-lg text-muted-foreground hover:text-primary hover:bg-muted transition-all">
              <Icon size={20} />
            </a>
          ))}
          <a href="#hero" className="ml-4 p-2 rounded-lg bg-muted text-muted-foreground hover:text-primary transition-all" aria-label="Voltar ao topo">
            <ArrowUp size={20} />
          </a>
        </div>
      </div>
    </footer>
  );
}
