import { useTheme } from "@/hooks/useTheme";
import Header from "@/components/portfolio/Header";
import Hero from "@/components/portfolio/Hero";
import About from "@/components/portfolio/About";
import Skills from "@/components/portfolio/Skills";
import Stats from "@/components/portfolio/Stats";
import Projects from "@/components/portfolio/Projects";
import Experience from "@/components/portfolio/Experience";
import Testimonials from "@/components/portfolio/Testimonials";
import Partners from "@/components/portfolio/Partners";
import Contact from "@/components/portfolio/Contact";
import Footer from "@/components/portfolio/Footer";

export default function Index() {
  const { dark, toggle } = useTheme();

  return (
    <div className="min-h-screen bg-background text-foreground">
      <Header dark={dark} toggle={toggle} />
      <Hero />
      <About />
      <Skills />
      <Stats />
      <Projects />
      <Experience />
      <Testimonials />
      <Partners />
      <Contact />
      <Footer />
    </div>
  );
}
