import SectionTitle from "./SectionTitle";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const timeline = [
  { year: "2026", title: "Fundação", desc: "CyberPulse Innovations é fundada com foco em segurança ofensiva." },
  { year: "2026", title: "Primeiro Grande Cliente", desc: "Contrato com empresa do setor financeiro para auditoria completa." },
  { year: "2026", title: "Expansão de Serviços", desc: "Inclusão de desenvolvimento seguro e consultoria em cloud security." },
  { year: "2026", title: "Marco de 50 Clientes", desc: "Alcançamos 50 clientes ativos com taxa de retenção de 95%." },
];

export default function Experience() {
  const { ref, isVisible } = useScrollAnimation(0.1);
  return (
    <section className="py-24 px-4">
      <div className="max-w-4xl mx-auto">
        <SectionTitle label="Trajetória" title="Nossa História" />
        <div ref={ref} className="relative">
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-border" />
          {timeline.map((item, i) => (
            <div key={i} className={`relative flex md:items-center mb-12 last:mb-0 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`} style={{ transitionDelay: `${i * 150}ms` }}>
              <div className={`flex w-full ${i % 2 === 0 ? "md:flex-row" : "md:flex-row-reverse"}`}>
                <div className="hidden md:block md:w-1/2" />
                <div className="absolute left-4 md:left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-primary glow z-10" />
                <div className="ml-10 md:ml-0 md:w-1/2 md:px-8">
                  <div className="glass rounded-xl p-5">
                    <span className="font-mono text-xs text-primary">{item.year}</span>
                    <h3 className="font-semibold mt-1">{item.title}</h3>
                    <p className="text-sm text-muted-foreground mt-1">{item.desc}</p>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
