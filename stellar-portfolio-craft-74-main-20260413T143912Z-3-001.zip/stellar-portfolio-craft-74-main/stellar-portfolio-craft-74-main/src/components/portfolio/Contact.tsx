import { useState, FormEvent, useEffect, useRef } from "react";
import { Send, CheckCircle } from "lucide-react";
import SectionTitle from "./SectionTitle";

export default function Contact() {
  const formRef = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);
  const [sent, setSent] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [form, setForm] = useState({ name: "", email: "", message: "" });

  useEffect(() => {
    const el = formRef.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setIsVisible(true); obs.unobserve(el); } }, { threshold: 0.15 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name.trim()) e.name = "Nome é obrigatório";
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = "Email inválido";
    if (!form.message.trim()) e.message = "Mensagem é obrigatória";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = (ev: FormEvent) => {
    ev.preventDefault();
    if (validate()) {
      setSent(true);
      setForm({ name: "", email: "", message: "" });
      setTimeout(() => setSent(false), 4000);
    }
  };

  return (
    <section id="contact" className="py-24 px-4 bg-muted/30">
      <div className="max-w-2xl mx-auto">
        <SectionTitle label="Contato" title="Fale Conosco" subtitle="Pronto para proteger seu negócio? Entre em contato." />
        <div ref={formRef} className={`transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <form onSubmit={handleSubmit} className="glass rounded-2xl p-8 space-y-5">
            {(["name", "email", "message"] as const).map((field) => (
              <div key={field}>
                <label className="block text-sm font-medium mb-1.5">{field === "name" ? "Nome" : field === "email" ? "Email" : "Mensagem"}</label>
                {field === "message" ? (
                  <textarea value={form[field]} onChange={(e) => setForm({ ...form, [field]: e.target.value })} rows={4} className="w-full rounded-xl bg-muted/50 border border-border px-4 py-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all resize-none" />
                ) : (
                  <input type={field === "email" ? "email" : "text"} value={form[field]} onChange={(e) => setForm({ ...form, [field]: e.target.value })} className="w-full rounded-xl bg-muted/50 border border-border px-4 py-3 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/50 transition-all" />
                )}
                {errors[field] && <p className="text-xs text-destructive mt-1">{errors[field]}</p>}
              </div>
            ))}
            <button type="submit" disabled={sent} className="w-full flex items-center justify-center gap-2 px-6 py-3.5 rounded-xl bg-primary text-primary-foreground font-semibold hover:opacity-90 transition-all glow disabled:opacity-50">
              {sent ? <><CheckCircle size={18} /> Enviado!</> : <><Send size={18} /> Enviar Mensagem</>}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
}
