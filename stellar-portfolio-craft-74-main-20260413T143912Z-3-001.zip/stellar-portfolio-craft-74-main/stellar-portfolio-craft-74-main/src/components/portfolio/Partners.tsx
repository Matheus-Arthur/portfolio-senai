import SectionTitle from "./SectionTitle";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import { Shield, Lock, Server, Cloud, Database, Cpu } from "lucide-react";

const partners = [
  { name: "SecureNet", icon: Shield },
  { name: "CloudGuard", icon: Cloud },
  { name: "DataShield", icon: Database },
  { name: "CyberForce", icon: Lock },
  { name: "NetDefense", icon: Server },
  { name: "AISecure", icon: Cpu },
];

export default function Partners() {
  const { ref, isVisible } = useScrollAnimation();
  return (
    <section className="py-24 px-4 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        <SectionTitle label="Parceiros" title="Empresas que Confiam em Nós" />
        <div ref={ref} className={`grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-6 transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          {partners.map(({ name, icon: Icon }, i) => (
            <div key={name} className="glass rounded-xl p-6 flex flex-col items-center gap-3 hover:glow transition-all group" style={{ transitionDelay: `${i * 80}ms` }}>
              <Icon size={32} className="text-muted-foreground group-hover:text-primary transition-colors" />
              <span className="text-xs font-medium text-muted-foreground group-hover:text-foreground transition-colors">{name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
