import { Star, Quote } from "lucide-react";
import SectionTitle from "./SectionTitle";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const testimonials = [
  { name: "Ricardo Mendes", role: "CTO, FinSecure", text: "A CyberPulse transformou nossa postura de segurança. Identificaram vulnerabilidades críticas que nenhum outro fornecedor encontrou.", stars: 5 },
  { name: "Ana Ferreira", role: "CEO, DataFlow", text: "Profissionalismo e expertise de primeiro nível. O dashboard de monitoramento que desenvolveram é excepcional.", stars: 5 },
  { name: "Carlos Souza", role: "Diretor de TI, LogiTech", text: "Equipe extremamente competente. O pentest realizado nos deu confiança total na nossa infraestrutura.", stars: 5 },
];

export default function Testimonials() {
  const { ref, isVisible } = useScrollAnimation(0.1);
  return (
    <section id="testimonials" className="py-24 px-4">
      <div className="max-w-6xl mx-auto">
        <SectionTitle label="Depoimentos" title="O Que Dizem Nossos Clientes" />
        <div ref={ref} className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div key={t.name} className={`glass rounded-2xl p-6 relative transition-all duration-700 hover:glow ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`} style={{ transitionDelay: `${i * 150}ms` }}>
              <Quote size={32} className="text-primary/20 absolute top-4 right-4" />
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.stars }).map((_, j) => (
                  <Star key={j} size={16} className="fill-primary text-primary" />
                ))}
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed mb-6">"{t.text}"</p>
              <div>
                <p className="font-semibold text-sm">{t.name}</p>
                <p className="text-xs text-muted-foreground">{t.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
