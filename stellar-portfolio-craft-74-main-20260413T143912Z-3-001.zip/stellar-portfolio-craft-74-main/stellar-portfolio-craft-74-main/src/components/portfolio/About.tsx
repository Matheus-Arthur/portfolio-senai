import { Shield, Lock, Code, Server } from "lucide-react";
import SectionTitle from "./SectionTitle";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";
import logo from "@/assets/logo.png";

const highlights = [
  { icon: Shield, label: "Cibersegurança" },
  { icon: Lock, label: "Pentest" },
  { icon: Code, label: "Dev Seguro" },
  { icon: Server, label: "Infraestrutura" },
];

export default function About() {
  const { ref, isVisible } = useScrollAnimation();
  return (
    <section id="about" className="py-24 px-4">
      <div className="max-w-6xl mx-auto">
        <SectionTitle label="Sobre Nós" title="Quem Somos" subtitle="Inovação e proteção caminham juntas na CyberPulse Innovations." />
        <div ref={ref} className={`grid md:grid-cols-2 gap-12 items-center transition-all duration-700 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`}>
          <div className="relative flex justify-center">
            <div className="w-64 h-64 md:w-80 md:h-80 rounded-2xl glass p-8 flex items-center justify-center glow">
              <img src={logo} alt="CyberPulse" className="w-full h-full object-contain" />
            </div>
          </div>
          <div>
            <p className="text-muted-foreground leading-relaxed mb-6">
              A CyberPulse Innovations é uma empresa de tecnologia focada em cibersegurança e desenvolvimento de software seguro. Desde 2026, ajudamos empresas a protegerem seus ativos digitais com soluções robustas, auditorias de segurança e desenvolvimento de sistemas resilientes.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Nossa equipe combina expertise em segurança ofensiva e defensiva com as melhores práticas de engenharia de software, entregando projetos que priorizam a proteção sem sacrificar a experiência do usuário.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
              {highlights.map(({ icon: Icon, label }) => (
                <div key={label} className="flex flex-col items-center gap-2 p-4 rounded-xl bg-muted/50 hover:bg-muted transition-colors">
                  <Icon size={24} className="text-primary" />
                  <span className="text-xs font-medium text-muted-foreground">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
