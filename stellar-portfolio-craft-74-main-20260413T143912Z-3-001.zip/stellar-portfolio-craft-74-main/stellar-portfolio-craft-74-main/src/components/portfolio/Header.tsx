import { useState, useEffect } from "react";
import { Moon, Sun, Menu, X } from "lucide-react";
import logo from "@/assets/logo.png";

const navItems = [
  { label: "Início", href: "#hero" },
  { label: "Sobre", href: "#about" },
  { label: "Habilidades", href: "#skills" },
  { label: "Projetos", href: "#projects" },
  { label: "Depoimentos", href: "#testimonials" },
  { label: "Contato", href: "#contact" },
];

interface Props { dark: boolean; toggle: () => void; }

export default function Header({ dark, toggle }: Props) {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handler = () => setScrolled(window.scrollY > 50);
    window.addEventListener("scroll", handler, { passive: true });
    return () => window.removeEventListener("scroll", handler);
  }, []);

  return (
    <header className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${scrolled ? "glass shadow-lg" : "bg-transparent"}`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex items-center justify-between h-16 md:h-20">
        <a href="#hero" className="flex items-center gap-3">
          <img src={logo} alt="CyberPulse" className="h-10 w-10 object-contain" />
          <span className="text-lg font-bold text-foreground hidden sm:block">CyberPulse</span>
        </a>

        <nav className="hidden md:flex items-center gap-8">
          {navItems.map((item) => (
            <a key={item.href} href={item.href} className="text-sm font-medium text-muted-foreground hover:text-primary transition-colors relative after:absolute after:bottom-[-4px] after:left-0 after:w-0 after:h-0.5 after:bg-primary after:transition-all hover:after:w-full">
              {item.label}
            </a>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <button onClick={toggle} className="p-2 rounded-lg text-muted-foreground hover:text-primary hover:bg-muted transition-all" aria-label="Toggle theme">
            {dark ? <Sun size={20} /> : <Moon size={20} />}
          </button>
          <button onClick={() => setMenuOpen(!menuOpen)} className="md:hidden p-2 rounded-lg text-muted-foreground hover:text-primary hover:bg-muted transition-all" aria-label="Menu">
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>

      {menuOpen && (
        <nav className="md:hidden glass border-t border-border/50 px-4 py-4 space-y-3">
          {navItems.map((item) => (
            <a key={item.href} href={item.href} onClick={() => setMenuOpen(false)} className="block text-sm font-medium text-muted-foreground hover:text-primary transition-colors py-2">
              {item.label}
            </a>
          ))}
        </nav>
      )}
    </header>
  );
}
