import { useState } from "react";
import { ExternalLink, Github } from "lucide-react";
import SectionTitle from "./SectionTitle";
import { useScrollAnimation } from "@/hooks/useScrollAnimation";

const filters = ["Todos", "Segurança", "Web", "Automação", "Mobile"];

const projects = [
  { title: "SecureVault", desc: "Plataforma de gerenciamento de credenciais com criptografia E2E.", category: "Segurança", tags: ["Python", "React", "AES-256"], color: "from-primary/20 to-accent/10" },
  { title: "ThreatRadar", desc: "Dashboard de monitoramento de ameaças em tempo real com IA.", category: "Segurança", tags: ["TypeScript", "Next.js", "ML"], color: "from-primary/15 to-muted/30" },
  { title: "CodeAudit Pro", desc: "Ferramenta automatizada de análise estática de código-fonte.", category: "Automação", tags: ["Go", "Docker", "CI/CD"], color: "from-accent/15 to-primary/10" },
  { title: "ShieldAPI", desc: "API Gateway com WAF integrado e rate limiting inteligente.", category: "Web", tags: ["Node.js", "Redis", "Nginx"], color: "from-muted/20 to-primary/15" },
  { title: "PhishGuard", desc: "Sistema de detecção de phishing usando machine learning.", category: "Segurança", tags: ["Python", "TensorFlow", "Flask"], color: "from-primary/20 to-accent/15" },
  { title: "MobileSec SDK", desc: "SDK de segurança para aplicações mobile Android e iOS.", category: "Mobile", tags: ["Kotlin", "Swift", "C++"], color: "from-accent/10 to-primary/20" },
];

export default function Projects() {
  const [active, setActive] = useState("Todos");
  const { ref, isVisible } = useScrollAnimation(0.05);
  const filtered = active === "Todos" ? projects : projects.filter((p) => p.category === active);

  return (
    <section id="projects" className="py-24 px-4">
      <div className="max-w-6xl mx-auto">
        <SectionTitle label="Portfólio" title="Nossos Projetos" subtitle="Soluções que protegem e inovam o mercado digital." />

        <div className="flex flex-wrap justify-center gap-3 mb-12">
          {filters.map((f) => (
            <button key={f} onClick={() => setActive(f)} className={`px-5 py-2 rounded-full text-sm font-medium transition-all ${active === f ? "bg-primary text-primary-foreground glow" : "bg-muted text-muted-foreground hover:text-foreground"}`}>
              {f}
            </button>
          ))}
        </div>

        <div ref={ref} className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filtered.map((p, i) => (
            <div key={p.title} className={`group glass rounded-2xl overflow-hidden hover:glow transition-all duration-500 ${isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"}`} style={{ transitionDelay: `${i * 100}ms` }}>
              <div className={`h-40 bg-gradient-to-br ${p.color} flex items-center justify-center`}>
                <span className="text-4xl font-bold text-primary/30 group-hover:text-primary/50 transition-colors">{p.title[0]}</span>
              </div>
              <div className="p-6 space-y-3">
                <h3 className="text-lg font-semibold group-hover:text-primary transition-colors">{p.title}</h3>
                <p className="text-sm text-muted-foreground">{p.desc}</p>
                <div className="flex flex-wrap gap-2">
                  {p.tags.map((t) => (
                    <span key={t} className="text-xs font-mono px-2.5 py-1 rounded-md bg-muted text-muted-foreground">{t}</span>
                  ))}
                </div>
                <div className="flex gap-3 pt-2">
                  <button className="flex items-center gap-1.5 text-sm text-primary hover:underline"><ExternalLink size={14} /> Ver Projeto</button>
                  <button className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground"><Github size={14} /> GitHub</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
